<?php
include("include/head.inc.php");
include("librairie/fonctionClient.lib.php");

if (isset($_GET['action'])) {
    if ($_GET['action'] = 'creation') {
        if (creationCompte()) {
            echo msgErr(3);   // Création de compte effectuée
        } else {
            echo msgErr(2);      // Erreur de création de compte
        }
    }
}
?>

<br>
<form name="frmInscription" action="inscription.php?action=creation" enctype="multipart/form-data" method="post">

    <div class="row mb-3">
        <div class="col-2">
        </div>
        <div class="col-3 text-end">
            <label for="couriel" class="form-label">Courriel : </label>
        </div>
        <div class="col-4">
            <input type="couriel" id="couriel" name="courriel" size="70" class="form-control" placeholder="Entrer votre courriel" required>
        </div>
        <div class="col-3">
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-2">
        </div>
        <div class="col-3 text-end">
            <label for="password">Mot de passe : </label>
        </div>
        <div class="col-4">
            <input type="password" id="email" name="password" size="15" class="form-control" placeholder="Mot de passe" required>
        </div>
        <div class="col-3">
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-2">
        </div>
        <div class="col-3 text-end">
            <label for="nom">Votre prénom : </label>
        </div>
        <div class="col-4">
            <input type="text" id="nom" name="prenom" size="50" class="form-control" placeholder="Votre prénom" required>
        </div>
        <div class="col-3">
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-2">
        </div>
        <div class="col-3 text-end">
            <label for="nom">Votre nom : </label>
        </div>
        <div class="col-4">
            <input type="text" id="nom" name="nom" size="50" class="form-control" placeholder="Votre nom" required>
        </div>
        <div class="col-3">
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-1">
        </div>
        <div class="col-4 text-end">
            <label for="dtn">Date de naissance : </label>
        </div>
        <div class="col-4">
            <input type="date" id="dtn" name="dtn" class="form-control" required>
        </div>
        <div class="col-3">
        </div>
    </div>


    <div class="row mb-3">
        <div class="col-2">
        </div>
        <div class="col-3 text-end">
            <label for="telephone" class="form-label">Téléphone : </label>
        </div>
        <div class="col-4">
            <input type='tel' id='phone' name='phone' pattern='[0-9]{3}-[0-9]{3}-[0-9]{4}' class="form-control" placeholder="999-999-9999" required>
        </div>
        <div class="col-3">
        </div>
    </div>

    <div class="row mb-3"">
        <div class=" col-2">
    </div>
    <div class="col-3 text-end">
        <label for="avatar" class="form-label">Votre photo : </label>
    </div>
    <div class="col-4">
        <input type="hidden" name="MAX_FILE_SIZE" value="250000">
        <input class="form-control" type="file" size=60 name="fichier" id="fichier">
    </div>
    <div class="col-3">
    </div>
    </div>

    <div class="row mb-3"">
        <div class=" col-5">
    </div>
    <div class="col-3">
        <input type="submit" class="btn btn-secondary text-light" value="Créer">
        <input type="reset" class="btn btn-secondary text-light" value="Annuler">
    </div>
    <div class="col-4">
    </div>
    </div>

</form>


<?php
include("include/foot.inc.php");
?>