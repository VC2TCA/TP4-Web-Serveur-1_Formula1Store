<?php
include("include/head.inc.php");
include("librairie/fonctionClient.lib.php");

if (isset($_GET['action'])) {
    if ($_GET['action'] == 'connexion') {
        if (verificationUser()) {
            header("Location:produit.php");
        } else {
            msgErr(1);    // erreur authentification
        }
    }
}
?>

<body><br>
    <form action="connexion.php?action=connexion" method="post">
        <div class="row mb-3">
            <div class="col-2">
            </div>
            <div class="col-3 text-end">
                <label for="courriel">Courriel : </label>
            </div>
            <div class="col-4">
                <input type="email" id="identifiant" name="identifiant" size="50" class="form-control" placeholder="Votre courriel" required>
            </div>
            <div class="col-3">
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-2">
            </div>
            <div class="col-3 text-end">
                <label for="password">Mot de passe : </label>
            </div>
            <div class="col-4">
                <input type="password" id="password" name="password" size="15" class="form-control" placeholder="Mot de passe" required>
            </div>
            <div class="col-3">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-5">
            </div>
            <div class="col-2">
                <input type="submit" value="Connexion">
            </div>
            <div class="col-5">
            </div>
        </div>

    </form>
</body>
<?php
include("include/foot.inc.php");
?>