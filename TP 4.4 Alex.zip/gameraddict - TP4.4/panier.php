<?php
session_start();
include("include/head.inc.php");
include("librairie/fonctionClient.lib.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if (isset($_SESSION['idUsager'])) {
	$usager = $_SESSION['idUsager'];
	$nomComplet = $_SESSION['prenom'] . ' ' . $_SESSION['nom'];

	if (isset($_GET['action'])) {

		if ($_GET['action'] == 'supprimer') {
			$panier = $_GET['noPanier'];
			$produit = $_GET['no'];
			if (supprimerProduitPanier($panier, $produit)) {
				echo msgErr(13);  // Suppression de produit dans le panier OK
			} else {
				echo msgErr(12);  // Suppression de produit dans le panier en erreur
			}
		}

		if ($_GET['action'] == 'modifier') {
			$panier = $_GET['noPanier'];
			$produit = $_GET['no'];
			$qteVendue = $_POST['quantite'];
			if (modifierPanier($panier, $produit, $qteVendue)) {
				echo msgErr(15);  // Modification quantité produit dans le panier OK
			} else {
				echo msgErr(14);  // Modification quantité produit dans le panier en erreur
			}
		}

		if ($_GET['action'] == 'commanderPanier') {
			$panier = $_GET['noPanier'];
			// Étape 1: Envoyer par courriel le résumé de la commande au client
			// Étape 2: Supprimer le panier de la table panier.  La table datailpanier va se supprimer automatiquement.
			$mail = new PHPMailer(true);
			$adrCourriel = $usager;
			if (envoyerMail($mail, $adrCourriel, $nomComplet)) {
				if (supprimerPanier($panier)) {
					echo msgErr(16);  // Commande effectuée avec succès !!!
				} else {
					echo msgErr(17);  // Commande non effectuée 
				}
			} else {
				echo msgErr(18);  // Envoie du courriel de la commande en erreur
			}
		}
	}

	afficherPanier($usager);
} else {   // Le client n'est pas connecté à son compte
	echo <<<HTML
                <div class='row text-warning bg-dark mt-5 ms-5 me-5 font-monospace'>
                        <p class='text-center fs-5 pt-2'>
							Veuillez vous connecter sur votre compte pour accéder à votre panier
						</p>                
                </div>
HTML;
}

include("include/foot.inc.php");
