<?php
// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
// F O N C T I O N S   A S S O C I E S   A   L' A D M I N I S T R A T E U R 
// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

include("administration.lib.php");

// Ajouter Produit
// ---------------
function ajouterProduit()
{
    connexionBD($dbh);

    // Préparation et validation du téléversement du fichier    

    if (ajouterImageDossier($nomImage)) {
        // Image transféré sur le dossier. Préparation des données pour l'ajout du produit   
        $nomProduit = securiserDonnees($_POST["nomProduit"]);
        $fournisseur = securiserDonnees($_POST["fournisseur"]);
        $quantite = securiserDonnees($_POST["quantite"]);
        $console = securiserDonnees($_POST["console"]);
        $prix = securiserDonnees($_POST["prix"]);
        $description = securiserDonnees($_POST["description"]);
        $age = securiserDonnees($_POST["age"]);

        $sql = "INSERT INTO produit 
                (nomProduit, fournisseur, quantite, console, prix, description, age, imageNom)
                VALUES 
                (:nomProduit, :fournisseur, :quantite, :console, :prix, :description, :age, :imageNom)";

        $stmt = $dbh->prepare($sql);

        $stmt->bindValue(':nomProduit', $nomProduit);
        $stmt->bindValue(':fournisseur', $fournisseur);
        $stmt->bindValue(':quantite', $quantite);
        $stmt->bindValue(':console', $console);
        $stmt->bindValue(':prix', $prix);
        $stmt->bindValue(':description', $description);
        $stmt->bindValue(':age', $age);
        $stmt->bindValue(':imageNom', $nomImage);

        try {
            $stmt->execute();
            return true;
        } catch (PDOException $e) {
            return false;
        }
    } else {
        echo msgErr(6);   // Transert image du produit dans dossier image en erreur.
        return false;
    }
}

// Ajouter l'image du produit dans le dossier "image/produits"
// ----------------------------------------------------------
function ajouterImageDossier(&$nomImage)
{
    unset($erreur);
    // valider selon les paramètres de php.ini
    // ----------------------------------------  
    if ($_FILES['image']['error']) {
        switch ($_FILES['photo']['error']) {
            case 1: // UPLOAD_ERR_INI_SIZE
                $erreur = "Le fichier dépasse la limite autorisée par le serveur (fichier php.ini) !";
                break;

            case 2: // UPLOAD_ERR_FORM_SIZE
                $erreur = "Le fichier dépasse la limite autorisée dans le formulaire HTML (MAX_FILE_SIZE) !";
                break;

            case 3: // UPLOAD_ERR_PARTIAL
                $erreur = "L'envoi du fichier a été interrompu pendant le transfert !";
                break;

            case 4: // UPLOAD_ERR_NO_FILE
                $erreur = "Le fichier que vous avez envoyé a une taille nulle !";
                break;

            case 6: // UPLOAD_ERR_NO_TMP_DIR
                $erreur = "Un dossier temporaire est manquant !";
                break;

            case 7: // UPLOAD_ERR_CANT_WRITE
                $erreur = "Échec écriture du fichier sur le disque !";
                break;

            case 8: // UPLOAD_ERR_EXTENSION
                $erreur = "L\'envoie du fichier est arrêté par l\'extension !";
                break;
        }
    } else {    // pas d'erreur PHP.ini
        $extensions_ok = array('png', 'PNG', 'gif', 'GIF', 'jpg', 'JPG', 'jpeg', 'JPEG');
        $taille_max = 256000;
        $dest_dossier = 'Image/produits/';

        // vérifications des extension permises
        // strrchr trouve la dernière occurrence d'un caractère dans une chaîne
        if (!in_array(substr(strrchr($_FILES['image']['name'], '.'), 1), $extensions_ok)) {  // "toto.jpg" --> ".jpg" --> "jpg"
            $erreur = 'Veuillez sélectionner un fichier de type png, gif ou jpg !';
        } else {
            // Vérification programmée de la grosseur du fichier.
            if ($_FILES['image']['size'] > $taille_max) {             // filesize($_FILES['photo']['tmp_name'])
                $erreur = 'Votre fichier doit faire moins de 256Ko !';
            }
        }

        // Normaliser le nom du fichier (aucun accent et carac. spécial
        // ------------------------------------------------------------
        if (!isset($erreur)) {
            $nomImage = basename($_FILES['image']['name']);
            // formatage nom fichier, enlever les accents
            $nomImage = strtr(
                $nomImage,
                'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ',
                'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy'
            );
            // remplacer les caracteres autres que lettres, chiffres et point par _
            $nomFichier = preg_replace('/([^.a-z0-9]+)/i', '_', $nomImage);
            // copie du fichier
            move_uploaded_file($_FILES['image']['tmp_name'], $dest_dossier . $nomImage);
        }
    }

    if (isset($erreur)) {
        echo '<p>', $erreur, '</p>';
        return false;
    } else {
        return true;
    }
}

// Afficher liste Produit pour suppression
// ----------------------------------------
function listerLesProduitsSuppr()
{
    connexionBD($dbh);

    $sql = "SELECT * FROM produit";
    $stmt = $dbh->prepare($sql);
    $stmt->execute();

    echo '<form name="Suppression" action="supprimerProduit.php?action=supprimer" method="post"><br>';
    foreach ($stmt as $row) {
        $idProduit = $row['idProduit'];
        $nomProduit = $row['nomProduit'];
        $fournisseur = $row['fournisseur'];
        $imageNom = $row['imageNom'];

        echo <<<HTML
            <div class='row mt-1 ms-5 me-5'>
                <div class='col-2'>              
                </div>
                <div class='col-3 border border-secondary pt-3'> 
                    <p>$nomProduit</p>               
                </div>

                <div class='col-1 border border-secondary pt-1'>
                    <img class='img-fluid rounded mx-auto d-block' src=Image/produits/$imageNom width=40px alt='Produit'>               
                </div>

                <div class='col-2 border border-secondary pt-3'>
                    <p>$fournisseur</p>
                </div>

                <div class="col-1 border border-secondary pt-3 ps-4">
                    <input class="form-check-input" type="checkbox" id="$idProduit" name="$idProduit" value=$idProduit>
                    <label class="form-check-label" for="$idProduit"></label>
                </div>

                <div class='col-2'>              
                </div>

            </div>


HTML;
    }

    echo <<<HTML
        <div class="row ms-5 me-5 mt-3">
            <div class="col-2">
            </div>
            <div class="col-5">
                <input type="submit" class="btn btn-secondary text-light" value="Supprimer">
                <input type="reset" class="btn btn-secondary text-light" value="Annuler">
            </div>
            <div class="col-4">
            </div>
        </div>
    </form>
HTML;
};

function supprimerProduitSelect()
{
    connexionBD($dbh);

    foreach ($_POST as $idProduit) {

        $sql = "DELETE FROM produit
        WHERE idProduit = $idProduit";

        $stmt = $dbh->prepare($sql);
        try {
            $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    return true;
}

// Afficher la liste des produits pour modification
// ------------------------------------------------
function listerLesProduitsMod()
{
    connexionBD($dbh);

    $sql = "SELECT * FROM produit";
    $stmt = $dbh->prepare($sql);
    $stmt->execute();

    foreach ($stmt as $row) {
        $idProduit = $row['idProduit'];
        $nomProduit = $row['nomProduit'];
        $fournisseur = $row['fournisseur'];
        $imageNom = $row['imageNom'];

        echo <<<HTML
            <div class='row mt-2 ms-5 me-5'>
                <div class='col-2'>              
                </div>
                <div class='col-3 border border-secondary pt-3'> 
                    <p>$nomProduit</p>               
                </div>

                <div class='col-1 border border-secondary pt-1'>
                    <img class='img-fluid rounded mx-auto d-block' src=image/produits/$imageNom width=40px alt='Produit'>               
                </div>

                <div class='col-2 border border-secondary pt-3'>
                    <p>$fournisseur</p>
                </div>

                <div class='col-2 pt-3 ps-3 border border-secondary'>
                        <form name="$idProduit" action="modifierProduit.php?action=modifier&no=$idProduit" method="post">
                            <input type='submit' class='btn btn-secondary text-light' name='modifier' value='Modifier'>
                        </form>
                </div>
                <div class='col-2'>              
                </div>

            </div>
HTML;
    }
};


// Afficher le Produit sélectionné pour modification
// -------------------------------------------------
function afficherLeProduitMod($produit)
{

    connexionBD($dbh);

    $sql = "SELECT * FROM produit WHERE idProduit = $produit";
    $stmt = $dbh->prepare($sql);

    try {
        $stmt->execute();

        foreach ($stmt as $row) {
            $idProduit = $row['idProduit'];
            $nomProduit = $row['nomProduit'];
            $fournisseur = $row['fournisseur'];
            $quantite = $row['quantite'];
            $console = $row['console'];
            $prix = $row['prix'];
            $description = $row['description'];
            $age = $row['age'];
            $imageNom = $row['imageNom'];

            echo <<<HTML
                <form action="modifierProduit.php?action=enregistrer&no=$idProduit" enctype="multipart/form-data" method="post">
    
                <div class="row mb-3">
                    <div class="col-2"> 
                    </div>
                    <div class="col-3 text-end pt-1">
                        <label for="nom">Votre nom : </label>   
                    </div>
                    <div class="col-4">
                        <input type="text" id="nomProduit" name="nomProduit" size="25" class="form-control" placeholder="Nom du produit" value="$nomProduit" required>
                    </div>
                    <div class="col-3"> 
                    </div>
                </div>
    
                <div class="row mb-3">
                    <div class="col-2"> 
                    </div>
                    <div class="col-3 text-end pt-1">
                        <label for="nom">Prix : </label>   
                    </div>
                    <div class="col-4">
                        <input type="text" id="prix" name="prix" size="10" class="form-control" placeholder="Prix $" value="$prix" required>
                    </div>
                    <div class="col-3"> 
                    </div>
                </div>
    
                <div class="row mb-3">
                    <div class="col-2"> 
                    </div>
                    <div class="col-3 text-end pt-1">
			            <label for="nom">Fournisseur : </label>
		            </div>
                    <div class="col-4">
                        <select name="fournisseur" id="fournisseur" class="form-select">
                            <option value="Sony">Sony</option>
                            <option value="Microsoft">Microsoft</option>
                            <option value="Steam">Steam</option>
                            <option value="Nitendo">Nitendo</option>
                            <option value="GooglePlay">GooglePlay</option>
                            <option value="Activision">Activision</option>
                        </select>
                    </div>
                    <div class="col-3"> 
                    </div>
                </div>
    
                <div class="row mb-3">
                    <div class="col-2"> 
                    </div>
                    <div class="col-3 text-end pt-1">
                        <label for="nom">Quantité pour l'inventaire : </label>   
                    </div>
                    <div class="col-4">
                        <input type='number' style='width:5rem' class='form-control' id='quantite' name='quantite' min='0' max='1000' value="$quantite">
                    </div>
                    <div class="col-3"> 
                    </div>
                </div>
    
                <div class="row mb-3">
                    <div class="col-2"> 
                    </div>
                    <div class="col-3 text-end pt-1">
                        <label for="nom">Console de jeu : </label>   
                    </div>
                    <div class="col-4">
                        <select name="console" id="console" class="form-select" value="$console">
                            <option value="XBOX One">XBOX One</option>
                            <option value="XBOX 360">XBOX 360</option>
                            <option value="XBOX 720">XBOX 720</option>
                            <option value="Play Station 4">Play Station 4</option>
                            <option value="Play Station 5">Play Station 5</option>
                            <option value="Play Station 8">Play Station 8</option>
                            <option value="Nitendo Wii">Nitendo Wii</option>
                            <option value="Nitendo Switch">Nitendo Switch</option>
                            <option value="Steam Plus">Steam Plus</option>
                            <option value="Sega">Sega</option>
                        </select>
                    </div>
                    <div class="col-3"> 
                    </div>
                </div>
    
                <div class="row mb-3">
                    <div class="col-2"> 
                    </div>
                    <div class="col-3 text-end pt-1">
                        <label for="description">Description : </label>   
                    </div>
                    <div class="col-4">
                        <textarea name="description" class="form-control" aria-label="description">$description</textarea>
                    </div>
                    <div class="col-3"> 
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-2">
                    </div>
                    <div class="col-3 text-end pt-1">
                        <label for="age">Age légal : </label>
                    </div>
                    <div class="col-4">
                        <input type='number' style='width:5rem' class='form-control' id='age' name='age' min='9' max='21' value="$age">
                    </div>
                    <div class="col-3">
                    </div>
                </div>
    
                <div class="row mb-3">
                    <div class="col-2">
                    </div>
                    <div class="col-3 text-end">
                        <label for="avatar"class="form-label">Image du produit : </label>  
                    </div>
                    <div class="col-4">
                        <input type="hidden" name="MAX_FILE_SIZE" value="250000"> 
                        <input class="form-control" type="file" size=60 name="fichier" id="fichier">
                    </div>
                    <div class="col-3">
                    </div>
                </div>
    
                <div class="row mb-3">
                    <div class="col-5">
                    </div>
                    <div class="col-3">
                        <input type="submit" class="btn btn-secondary text-light" value="Enregistrer">
                        <input type="reset" class="btn btn-secondary text-light" value="Annuler">
                    </div>
                    <div class="col-4">
                    </div>
                </div>
    
                </form>
HTML;
        }
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

function majLeProduit($produit)
{
    connexionBD($dbh);

    $nomProduit = securiserDonnees($_POST["nomProduit"]);
    $fournisseur = securiserDonnees($_POST["fournisseur"]);
    $quantite = securiserDonnees($_POST["quantite"]);
    $console = securiserDonnees($_POST["console"]);
    $prix = securiserDonnees($_POST["prix"]);
    $description = securiserDonnees($_POST["description"]);
    $age = securiserDonnees($_POST["age"]);

    $sql = "UPDATE produit
            SET nomProduit='$nomProduit',
                fournisseur='$fournisseur',
                quantite=$quantite,
                console='$console',
                prix=$prix,
                description='$description',
                age='$age'
            WHERE idProduit = $produit";

    $stmt = $dbh->prepare($sql);

    try {
        $stmt->execute();
        return true;
    } catch (PDOException $e) {
        return false;
    }
}
