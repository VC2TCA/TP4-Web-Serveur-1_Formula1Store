<?php
// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
// F O N C T I O N S   A S S O C I E S   A U   C L I E N T 
// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

include("administration.lib.php");

// Verification connexion usager
// --> admin = adminitrateur du système
// --> courriel = client
// ---------------------------------------------
function verificationUser()
{
    connexionBD($dbh);

    $sql = "SELECT * FROM usager WHERE idUsager = ?";
    $stmt = $dbh->prepare($sql);
    $stmt->execute([$_POST['identifiant']]);

    foreach ($stmt as $row) {
        if ($row['idUsager'] = $_POST['identifiant']) {
            if ($row['password'] = $_POST['password']) {
                session_start();
                $_SESSION['idUsager'] = $row['idUsager'];
                $_SESSION['prenom'] = $row['prenom'];
                $_SESSION['nom'] = $row['nom'];
                $_SESSION['photo'] = $row['photoData'];
                return true;
            }
        }
    }
    return false;
}
// Création compte utilisateur
// ---------------------------
function creationCompte()
{
    connexionBD($dbh);

    // Préparation et validation du téléversement du fichier 

    $img_taille = 0;
    $img_type = '';
    $taille_max = 64000;

    $ret = is_uploaded_file($_FILES['fichier']['tmp_name']);
    if (!$ret) {
        echo "Problème de transfert sur le tmp_name";
        return false;
    } else {
        // Le fichier a bien été reçu
        $img_taille = $_FILES['fichier']['size'];
        if ($img_taille > $taille_max) {
            echo "Fichier supérieur à 64Ko";
            return false;
        } else {
            $img_type = $_FILES['fichier']['type'];
            $img_Data = file_get_contents($_FILES['fichier']['tmp_name']);
        }
    }
    // Préparationdes autres données 

    $courriel = securiserDonnees($_POST["courriel"]);
    $password = securiserDonnees($_POST["password"]);
    $prenom = securiserDonnees($_POST["prenom"]);
    $nom = securiserDonnees($_POST["nom"]);
    $dtn = securiserDonnees($_POST["dtn"]);
    $phone = securiserDonnees($_POST["phone"]);

    $sql = "INSERT INTO usager 
            (idUsager, password, prenom, nom, dateNaiss, telephone, photoType, photoData)
			VALUES 
            (:courriel, :password, :prenom, :nom, :dtn, :phone, :img_type, :img_Data)";

    $stmt = $dbh->prepare($sql);

    $stmt->bindValue(':courriel', $courriel);
    $stmt->bindValue(':password', $password);
    $stmt->bindValue(':prenom', $prenom);
    $stmt->bindValue(':nom', $nom);
    $stmt->bindValue(':dtn', $dtn);
    $stmt->bindValue(':phone', $phone);
    $stmt->bindValue(':img_type', $img_type);
    $stmt->bindValue(':img_Data', $img_Data);

    try {
        $stmt->execute();
        return true;
    } catch (PDOException $e) {
        echo msgErr(2) . $e->getMessage();
    }
}


// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
// G E S T I O N    D U   C L I E N T 
// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

// Afficher liste Produit
// -------------------------
function afficherProduit()
{
    connexionBD($dbh);

    $sql = "SELECT * FROM produit";
    $stmt = $dbh->prepare($sql);
    $stmt->execute();

    foreach ($stmt as $row) {
        $idProduit = $row['idProduit'];
        $nomProduit = $row['nomProduit'];
        $fournisseur = $row['fournisseur'];
        $quantite = $row['quantite'];
        $console = $row['console'];
        $prix = $row['prix'];
        $description = $row['description'];
        $age = $row['age'];
        $imageNom = $row['imageNom'];

        echo <<<HTML
            <div class='row border border-warning mt-3 ms-5 me-5 font-monospace'>
                <div class='col-3 border border-warning'> 
                    <p class='fs-4 p-auto text-danger'>$nomProduit</p> 
                    <p>$description</p>                
                </div>

                <div class='col-2 border border-warning pt-3'>
                    <img class='img-fluid rounded mx-auto d-block' src="Image/produits/$imageNom" style="width=120px" alt='Produit'>               
                </div>

                <div class='col-3 border border-warning'>
                    <p><b>Prix: </b>$prix</p>
                    <p><b>Disponibilité: </b>$quantite</p>
                    <p><b>Console: </b>$console</p>
                    <p><b>Fournisseur </b>$fournisseur</p>
                    <p><b>Age : </b>$age</p>
                </div>

                <div class='col-4 pt-4 ps-3 border'>
                        <form name="$idProduit" action="Produit.php?action=ajouterProduitPanier&no=$idProduit" method="post">
                            <label for='qte'>Quantité : </label> 
                            <input type='number' style='width:5rem' class='form-control' id='quantite' name='quantite' min='0' max='100'>
                            <br>
                            <input type='submit' class='btn btn-secondary text-light' name='ajouter' value='Ajouter au panier'>
                        </form>
                </div>

            </div>
HTML;
    }
};

// Afficher le panier
// ------------------
function afficherPanier($usager)
{
    connexionBD($dbh);

    // Obtenir la clé du panier pour accéder au détail du panier 
    // ---------------------------------------------------------
    $clePanier = obtenirClePanier($usager);
    if ($clePanier > 0) {
        afficherDetailPanier($clePanier);
    }
}

// Obtenir la clé du panier du client
// ----------------------------------
function obtenirClePanier($usager)
{
    connexionBD($dbh);

    // Vérifier la présence d'un panier pour le client.
    // Clé du panier = 0 (Panier absent)
    // Clé du panier <> 0 (Panier présent)
    // -----------------------------------------------
    $clePanier = 0;

    $sql = "SELECT * FROM panier WHERE idUsager = '$usager'";

    $stmt = $dbh->prepare($sql);
    $stmt->execute();

    foreach ($stmt as $row) {
        $clePanier = $row['idPanier'];
    }

    return $clePanier;
}

// Afficher le détail du panier
// ----------------------------
function afficherDetailPanier($clePanier)
{
    connexionBD($dbh);

    $sql = "SELECT *
            FROM panier
            INNER JOIN detailpanier ON panier.idPanier = detailpanier.idPanier 
                AND panier.idPanier = $clePanier
            INNER JOIN produit ON detailpanier.idProduit = produit.idProduit";

    $stmt = $dbh->prepare($sql);
    $stmt->execute();

    $total = 0;
    // Préparer liste des produits du panier
    // -------------------------------------
    foreach ($stmt as $row) {
        $idProduit = $row['idProduit'];
        $qteVendue = $row['qteVendue'];
        $nomProduit = $row['nomProduit'];
        $fournisseur = $row['fournisseur'];
        $quantite = $row['quantite'];
        $console = $row['console'];
        $prix = $row['prix'];
        $description = $row['description'];
        $age = $row['age'];
        $imageNom = $row['imageNom'];
        $sousTot = ($qteVendue * $prix);
        $total = $total + $sousTot;
        $sousTot = number_format($sousTot, 2);

        // Valeur pour le OffCanvas. Ils seront conservés dans des champs cachés dans le formulaire
        // pour la production du courriel du client
        $mntTPS = number_format($total * 0.095, 2);
        $mntTVQ = number_format(($total + ($total * 0.095)) * 0.05, 2);
        $grandTotal = number_format($total * 1.14975, 2);
        $total = number_format($total, 2);

        echo <<<HTML
            <div class='row mt-3 ms-5 me-5 font-monospace'>
                <div class='col-3 border border-warning'> 
                    <p class='fs-4 p-auto text-danger'>$nomProduit</p> 
                    <p>$description</p>                
                </div>

                <div class='col-2 border border-warning pt-3'>
                    <img class='img-fluid rounded mx-auto d-block' src=Image/produits/$imageNom width=100px alt='Produit'>               
                </div>

                <div class='col-3 border border-warning'>
                    <p><b>Prix: $</b>$prix</p>
                    <p class='lh-1'><b>Console: </b>$console</p>
                    <p class='lh-1'><b>Fournisseur </b>$fournisseur</p>
                    <p class='lh-1'><b>Age légal: </b>$age</p>
                    <p class='bg-dark text-primary fs-5'><b>Sous-total: $</b>$sousTot</p>

                </div>

                <div class='col-3 pt-2 ps-5 border border-warning'>

                    <form name="$idProduit" action="panier.php?action=modifier&noPanier=$clePanier&no=$idProduit" method="post">
                        <div class="input-group mb-3">
                            <span class="input-group-text">Quantité:</span>
                            <input type='number' style='width:5rem' class='form-control' id='quantite' name='quantite' min='0' max='100' value="$qteVendue">
                            <input type='submit' class='btn btn-secondary text-light mt-1' name='modifier' value='modifier'>
                        </div>
                    </form>

                    <form name="$idProduit" action="panier.php?action=supprimer&noPanier=$clePanier&no=$idProduit" method="post">
                        <br>
                        <input type='submit' class='btn btn-danger text-light' name='supprimer' value='Supprimer'>
                    </form>
                </div>

                <div class='col-4'>              
                </div>

            </div>
HTML;
    }

    // Préparer la fenêtre offCanvas (Résumé de la commande)
    // ------------------------------------------------------
    echo <<<HTML
    <div class="offcanvas offcanvas-end" id="demo">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Résumé de votre commande</h5>
            <button type="button" class="btn btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body">
            <br>
            <p class="text-center">Merci d'avoir commander vos jeux sur AddictGamer.  Vous recevrez votre commande d'ici
                10 jours ouvrable via Purolator.  En cas d'insatisfaction de votre part, veuillez communiquer avec 
                notre département des plaintes soit par téléphone au 1-800-234-5566 ou par courriel à l'adresse
                suivante servicedesplaintes@addictgamer.com.  Merci.
            </p>
            <p class="text-end"><b>Total: $</b>$total</p>
            <p class="text-end"><b>TPS: $</b>$mntTPS</p>
            <p class="text-end"><b>TVQ: $</b>$mntTVQ</p>
            <p class="text-end"><b>Total de la commande: $</b>$grandTotal</p>
            <br>
        </div>
  </div>
  
  <div class="container-fluid mt-3">
    <button class="btn btn-secondary" type="button" data-bs-toggle="offcanvas" data-bs-target="#demo">
      Résumé de la commande
    </button>
    <form name="$idProduit" action="panier.php?action=commanderPanier&noPanier=$clePanier" method="post">
        <br>
        <input type='submit' class='btn btn-primary text-light' name='commander' value='Commander'>
        <input type="hidden" name="TPS" value="$mntTPS">
        <input type="hidden" name="TVQ" value="$mntTVQ">
        <input type="hidden" name="total" value="$total">
        <input type="hidden" name="grandTotal" value="$grandTotal">
        <br><br>
    </form>
  </div>
HTML;
};

// Ajouter produit dans le panier
// ------------------------------
function ajouterProduitPanier($usager, $produit, $quantite)
{
    connexionBD($dbh);

    // Obtenir la clé du panier pour ajouter un produit au panier 
    // ----------------------------------------------------------
    $clePanier = obtenirClePanier($usager);
    if ($clePanier == 0) {             // Panier inexistant, alors créer un panier
        $clePanier = creerPanier($usager);
    }

    $timeStamp = date('Y-m-d H:i:s');

    $sql = "INSERT INTO detailpanier(idPanier, idProduit, qteVendue, dateCreate, dateUpdate)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $dbh->prepare($sql);
    try {
        $stmt->execute(array($clePanier, $produit, $quantite, $timeStamp, $timeStamp));
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// Créer un panier au client
// ------------------------------
function creerPanier($usager)
{
    connexionBD($dbh);

    $timeStamp = date('Y-m-d H:i:s');

    $sql = "INSERT INTO panier(idUsager, dateCreation)
            VALUES (?, ?)";

    $stmt = $dbh->prepare($sql);
    try {
        $stmt->execute(array($usager, $timeStamp));
        $clePanier = $dbh->lastInsertId();
        return $clePanier;
    } catch (PDOException $e) {
        return false;
    }
}
// Supprimer produit dans le panier (À compléter...)
// -------------------------------------------------
function supprimerProduitPanier($panier, $produit)
{
    // Requête SQL "DELETE"
    connexionBD($dbh);

    $sql = "DELETE FROM detailPanier WHERE idPanier = :panier AND idProduit = :produit";

    $stmt = $dbh->prepare($sql);
    $stmt->bindValue(':panier', $panier);
    $stmt->bindValue(':produit', $produit);

    $stmt->execute();
}

// Modifier le panier  (À compléter...)
// ------------------------------------
function modifierPanier($panier, $produit, $quantite)
{
    // Requête SQL "UPDATE"
    connexionBD($dbh);

    $sql = "UPDATE detailpanier SET qteVendue = :newQte WHERE idPanier = :panier AND idProduit = :produit";
    $stmt = $dbh->prepare($sql);

    $stmt->bindValue(':panier', $panier);
    $stmt->bindValue(':produit', $produit);
    $stmt->bindValue(':newQte', $quantite);

    $stmt->execute();
}

// Supprimer le panier  (À compléter...)
// ------------------------------------
function supprimerPanier($panier)
{

    // Le courriel s'est bien envoyé.  Suprimer le panier.  Avec la contrainte
    // Delete cascade, vous n'avez qu'à supprimer le panier.  Les enregistrements
    // de la table detailPanier seront supprimer automatiquement.
    // -----------------------------------------------
    connexionBD($dbh);

    $sql = "DELETE FROM panier WHERE idPanier = :panier";

    $stmt = $dbh->prepare($sql);
    $stmt->bindValue(':panier', $panier);

    $stmt->execute();
}

// Envoyer courriel automatisé au client (À compléter...)
// --------------------------------------------------------
function envoyerMail($mail, $adrCourriel, $nomComplet)
{
    try {
        $mail->isSMTP();
        $mail->Host = 'mail.brocoli.disf-sandbox.ca'; // Identification du serveur SMTP servers.
        $mail->SMTPAuth = true;
        $mail->Username = 'gameraddict@brocoli.disf-sandbox.ca';
        $mail->Password = 'Brocoli1963$';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('gameraddict@brocoli.disf-sandbox.ca', 'GamerAddict.com');
        $mail->addAddress($adrCourriel);
        // Contenu du corps (body) de notre courriel
        //------------------------------------------
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        $mail->isHTML(true);  // Le courriel sera au format HTML
        //  $mail->AltBody = 'Le courriel sera au format non HTML';

        $mail->Subject = 'Commande F1 Store';
        $body =
            <<<HTML
            <div style="background-color: lightblue">
                <img src="Image/main-banner2.jpg">
                <h1>Merci $nomComplet pour votre commande !</h1>
            </div>
        HTML;

        // Appliquer la construction de notre $body dans le corps du message.
        $mail->Body = $body;

        $mail->send();
        return true;
    } catch (Exception $e) {
        echo "Le message est en erreur.  Voir le Debug: {$mail->ErrorInfo}";
    }
}
