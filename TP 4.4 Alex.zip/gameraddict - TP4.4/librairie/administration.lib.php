<?php
// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
// F O N C T I O N S   G E N E R A L E S   S Y S T E M E S  
// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

function connexionBD(&$dbh)
{
    $servname = "localhost";
    $dbname = "gameraddict";
    $user = "root";
    $pass = "";

    try {
        $dbh = new PDO("mysql:host=$servname;dbname=$dbname", $user, $pass);
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        $msg = 'ERREUR PDO dans ' . $e->getFile() . '<br> L.' . $e->getLine() . ' : ' . $e->getMessage();
        die($msg);
    }
}

// Gestion des message d'erreur
// ----------------------------
function msgErr($noMsg)
{
    $tabMsg = [
        "Err_000 - Tableau des messages applicatifs",
        "Err_001 - Le courriel ou le mot de passe est invalide",
        "Err_002 - Erreur de création de compte utilisateur :",
        "MSG_003 - Création de compte utilisateur effectué.  Veullez vous connectez.  Merci de magasiner chez addictGamer.",
        "Err_004 - Erreur ajout produit dans la table produit :",
        "MSG_005 - Ajout dans la table produit OK :",
        "Err_006 - Erreur de copie image dans le dossier Image : ",
        "MSG_007 - Suppression du / des produit(s) OK",
        "Err_008 - Suppression du / des produit(s) en erreur : ",
        "Err_009 - Produit introuvable ?",
        "MSG_010 - Mise à jour du produit OK",
        "Err_011 - Mise à jour du produit en erreur : ",
        "MSG_012 - Suppression de produit dans le panier OK",
        "Err_013 - Suppression de produit dans le panier en erreur : ",
        "MSG_014 - Modification quantité produit dans le panier OK",
        "Err_015 - Modification quantité produit dans le panier en erreur : ",
        "MSG_016 - Commande effectuée avec succès !!!",
        "Err_017 - Commande erronnée non effectuée",
        "Err_018 - Envoie du courriel de la commande du client en erreur",
    ];

    if ($tabMsg[$noMsg][0] == 'E') {
        $message = "<div class='bg-danger text-center'>" . $tabMsg[$noMsg] . "</div>";
    } else {
        $message = "<div class='bg-success text-center'>" . $tabMsg[$noMsg] . "</div>";
    }

    return $message;
}

function securiserDonnees($data)
{
    $data = trim($data);
    $data = htmlspecialchars($data);
    $data = addslashes($data);
    return $data;
}

// Afficher le contenu de $GLOBALS
// --------------------------------
function affGlobals($type_global)
{
    /*
$GLOBALS  = 1
$_SERVER  = 2
$_REQUEST = 3
$_GET     = 4
$_POST    = 5
$_FILES   = 6
$_ENV     = 7
$_COOKIE  = 8
$_SESSION = 9
*/


    switch ($type_global) {
        case "1":
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            echo '<pre>';
            print_r($GLOBALS);
            echo '</pre>';
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            break;
        case "2":
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            echo '<pre>';
            print_r($_SERVER);
            echo '</pre>';
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            break;
        case "3":
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            echo '<pre>';
            print_r($_REQUEST);
            echo '</pre>';
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';;
            break;
        case "4":
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            echo '<pre>';
            print_r($_GET);
            echo '</pre>';
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';;
            break;
        case "5":
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            echo '<pre>';
            print_r($_POST);
            echo '</pre>';
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';;
            break;
        case "6":
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            echo '<pre>';
            print_r($_FILES);
            echo '</pre>';
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            break;
        case "7":
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            echo '<pre>';
            print_r($_ENV);
            echo '</pre>';
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';;
            break;
        case "8":
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            echo '<pre>';
            print_r($_COOKIE);
            echo '</pre>';
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';;
            break;
        case "9":
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';
            echo '<pre>';
            print_r($_SESSION);
            echo '</pre>';
            echo '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%';;
            break;
        default:
            echo "Ne rien afficher !";
    }
}
