<?php
session_start();
if (isset($_SESSION['idUsager'])) {
    if ($_SESSION['idUsager'] != 'admin') {
        header("Location:index.php");
    }
}

include("include/headadmin.inc.php");
include("librairie/fonctionAdmin.lib.php");

if (isset($_GET['action'])) {
    if ($_GET['action'] == 'supprimer') {
        if (supprimerProduitSelect()) {
            echo msgErr(7);  // Suppression du / des produit(s) OK
            listerLesProduitsSuppr();
        } else {
            echo msgErr(8);      // Suppression du / des produit(s) en erreur
        }
    }
} else {
    // La liste des produits pour suppression
    listerLesProduitsSuppr();
}

include("include/footadmin.inc.php");
