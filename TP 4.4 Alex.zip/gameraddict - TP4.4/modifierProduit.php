<?php
session_start();
if (isset($_SESSION['idUsager'])) {
	if ($_SESSION['idUsager'] != 'admin') {
		header("Location:index.php");
	}
}

include("include/headadmin.inc.php");
include("librairie/fonctionAdmin.lib.php");

if (isset($_GET['action'])) {
	// 1- L'admin a cliqué sur le bouton modifier sur un des produits de la liste.  On afficher les détails du produit.
	if ($_GET['action'] == 'modifier') {
		$idProduit = $_GET['no'];
		if (!afficherLeProduitMod($idProduit)) {
			echo msgErr(9);  // Produit introuvable ?
		}
	}

	// 2- L'admin a modifier le produit et effectue la mis a jour.	
	if ($_GET['action'] == 'enregistrer') {
		$idProduit = $_GET['no'];
		if (majLeProduit($idProduit)) {
			echo msgErr(10);  // Mise à jour du produit OK
		} else {
			echo msgErr(11);  // Mise à jour du produit en erreur
		}
	}
} else {
	// La liste des produits est affiché pour l'administrateur
	listerLesProduitsMod();
}

include("include/footadmin.inc.php");
