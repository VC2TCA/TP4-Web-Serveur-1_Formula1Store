<?php
session_start();
if (!isset($_SESSION['courriel'])) {
  include("include/head.inc.php");
} else {
  include("include/headadmin.inc.html");
}

include("librairie/fonctionClient.lib.php");
?>

<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="Media/charlesShirtCarousel.png" class="d-block w-100" alt="caroussel1">
    </div>
    <div class="carousel-item">
      <img src="Media/maxShirtCarousel.png" class="d-block w-100" alt="caroussel2">
    </div>
    <div class="carousel-item">
      <img src="Media/pierreShirtCarousel.png" class="d-block w-100" alt="caroussel3">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<?php

if (isset($_SESSION['idUsager'])) {
  if ($_SESSION['idUsager'] == 'admin') {
    include("include/footadmin.inc.php");
  } else {
    include("include/foot.inc.php");
  }
} else {
  include("include/foot.inc.php");
}

?>