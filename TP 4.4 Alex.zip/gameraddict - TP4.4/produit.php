<?php
session_start();
include("include/head.inc.php");
include("librairie/fonctionClient.lib.php");

if (isset($_GET['action'])) {

	if (isset($_SESSION['idUsager'])) {
		if ($_GET['action'] == 'ajouterProduitPanier') {
			if ($_POST['quantite'] < 1) {
				echo "<div class='bg-dark text-danger'>La quantité doit être supérieur à 0</div>";
			} else {
				$usager = $_SESSION['idUsager'];
				$produit = $_GET['no'];
				$quantite = $_POST['quantite'];
				if (!ajouterProduitPanier($usager, $produit, $quantite)) {
					echo "<div class='bg-dark text-danger'>Le produit est déjà inclu dans votre panier</div>";
				}
			}
		}
	} else {
		echo <<<HTML
			<div class='row text-warning bg-dark mt-5 ms-5 me-5 font-monospace'>
					<p class='text-center fs-5 pt-2'>
						Veuillez vous connecter sur votre compte pour accéder à votre panier
					</p>                
			</div>
HTML;
	}
}
//affGlobals(2);
afficherProduit();

include("include/foot.inc.php");
