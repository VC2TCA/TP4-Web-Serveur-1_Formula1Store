
</div>

<div class=" row bg-secondary text-white footer fixed-bottom float-end ms-5 me-5">
    <div class="col-9">
        © Sylvain Branconnier - Tous droits réservés
    </div>  
    <div class="col-3">
        <script type="text/javascript">afficherDateJS()</script>
    </div> 
</div>

</body>

</html>