<!DOCTYPE html>
<html lang="fr">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://kit.fontawesome.com/50fa168acf.js" crossorigin="anonymous"></script>
  <script src="js/script.js"></script>
  <link href="css/script.css" rel="stylesheet">
  <link rel="icon" href="Media/logo.ico">
  <title>GamerAddict</title>
</head>

<body class="bg-secondary ms-5 me-5">

  <header>
    <div class="text-center mt-2">
      <img src="Image/main-banner2.png" width=100%>

      <nav class="navbar navbar-expand-lg navbar-light bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php"><img src="Image/logo.png" class="nav-link" width=80px></img></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse justify-content-between">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active text-danger" aria-current="page" href="produit.php">Produits</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="rejoindre.php">Nous rejoindre</a>
              </li>
              <li class="nav-item text-danger">
                <a href="panier.php" class="nav-link text-danger"><i class="fa-solid fa-cart-shopping"></i></a>
              </li>
            </ul>
            <ul class="navbar-nav pe-5">
              <li class="nav-item pt-3">
                <?php
                if (isset($_SESSION['photo'])) {
                  $photo = $_SESSION['photo'];
                  echo '<img src="data:image/jpeg;base64,' . base64_encode($photo) . '"width=40px></img>';
                }
                ?>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-danger" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i class="fa-solid fa-user text-danger"></i>
                </a>
                <ul class="dropdown-menu ml-auto" aria-labelledby="navbarDropdownMenuLink">
                  <li><a class="dropdown-item" href="connexion.php">Se connecter</a></li>
                  <li><a class="dropdown-item" href="inscription.php">Créer un compte</a></li>
                  <li><a class="dropdown-item" href="deconnexion.php">Se déconnecter</a></li>
                  <li><a class="dropdown-item text-danger bg-dark" href="connexionAdmin.php">Administrateur</a></li>
                </ul>
              </li>
            </ul>
          </div>

        </div>
      </nav>

    </div>

  </header>
  <div class="container">