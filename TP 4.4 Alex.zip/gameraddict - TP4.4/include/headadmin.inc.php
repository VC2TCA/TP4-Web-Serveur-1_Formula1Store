<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
  <link href="css/script.css" rel="stylesheet">
  <script src="js/script.js" type="text/javascript"></script>
  <link rel="icon" href="Image/logoJeu.png">
  <title>GamerAddict</title>
</head>

<body class="font-weight-bold ms-5 me-5">

  <header>
    <div class="text-center mt-2">
      <img src="image/main-banner2.png" width=100%>

      <nav class="navbar navbar-expand-lg navbar-light bg-secondary">
        <div class="container-fluid">

          <div class="collapse navbar-collapse justify-content-between">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active text-light" href="ajouterProduit.php">Ajouter Produit</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active text-light" href="modifierProduit.php">Modifier Produit</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active text-light" href="supprimerProduit.php">Supprimer Produit</a>
              </li>
            </ul>
            <ul class="navbar-nav pe-5">
              <li class="nav-item pt-3">
                <?php
                if (isset($_SESSION['photo'])) {
                  $photo = $_SESSION['photo'];
                  echo '<img src="data:image/jpeg;base64,' . base64_encode($photo) . '"width=120px></img>';
                }
                ?>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <img src="image/compte_w.png" class="nav-link" width=40px></img>
                </a>
                <ul class="dropdown-menu ml-auto" aria-labelledby="navbarDropdownMenuLink">
                  <li><a class="dropdown-item" href="connexion.php">Se connecter</a></li>
                  <li><a class="dropdown-item" href="inscription.php">Créer un compte</a></li>
                  <li><a class="dropdown-item" href="deconnexion.php">Se déconnecter</a></li>
                  <li><a class="dropdown-item text-danger bg-dark" href="connexionAdmin.php">Administrateur</a></li>
                </ul>
              </li>
            </ul>
          </div>

        </div>
      </nav>

    </div>

  </header>
  <div class="container">