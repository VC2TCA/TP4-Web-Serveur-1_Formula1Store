</div>

<div class="row bg-dark footer fixed-bottom float-end ms-5 me-5">
    <div class="col-9 text-danger">
        © Sylvain Branconnier - Tous droits réservés
    </div>
    <div class="col-3 text-danger">
        <script type="text/javascript">
            afficherDateJS()
        </script>
    </div>
</div>

</body>

</html>