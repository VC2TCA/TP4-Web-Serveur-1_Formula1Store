<?php 
class Usager {
	protected $user_name;
	protected $user_pass;

	public function __construct($n, $p){
		$this->user_name = $n;
		$this->user_pass = $p;
	}
	
	public function getNom(){
		return $this->user_name;
	}
	
	public function setNom($new_user_name){
		$this->user_name = $new_user_name;
	}
	
	public function setPasse($new_user_pass){
		$this->user_pass = $new_user_pass;
	}
}

class Admin extends Usager{
	///On tente d'afficher $user_name qui n'existe pas dans Admin
	public function getNom2(){
		return $this->user_name;
	}
	
	/*On surcharge la méthode getNom() de Utilisateur. Ici, on conserve
	 *le même code dans la méthode mais c'est cette méthode qui sera
	 *utilisée par $pierre*/
	public function getNom(){
		return $this->user_name;
	}
}


?> 
