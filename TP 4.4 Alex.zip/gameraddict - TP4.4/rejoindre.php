<?php
session_start();
include("include/head.inc.php");
include("librairie/fonctionClient.lib.php");

if (isset($_GET['action'])) {
    if ($_GET['action'] = 'mail') {
        $dest = "sbranconnier@hotmail.com";
        $sujet = $_POST['sujet'];
        $corp = $_POST['Commentaire'];
        $headers = $_POST['Courriel'];

        if (mail($dest, $sujet, $corp, $headers)) {
            echo "Email envoyé avec succès à $dest ...";
        } else {
            echo "Échec de l'envoi de l'email...";
        }
    }
}
?>
<br>
<form name="frm1" class="form-control" action="rejoindre.php?action=mail" method="post">

    <div class="row mb-3">
        <div class="col-2">
        </div>
        <div class="col-3 text-end pt-1">
            <label for="nom">Votre nom : </label>
        </div>
        <div class="col-4">
            <input type="text" id="nom" name="Nom" size="50" class="form-control" placeholder="Votre nom" required>
        </div>
        <div class="col-3">
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-2">
        </div>
        <div class="col-3 text-end pt-1">
            <label for="sujet" class="col-3">Sujet : </label>
        </div>
        <div class="col-4">
            <input type="sujet" id="sujet" name="sujet" size="520" class="form-control" placeholder="Votre sujet" required>
        </div>
        <div class="col-3">
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-2">
        </div>
        <div class="col-3 text-end pt-1">
            <label for="couriel" class="form-label">Courriel : </label>
        </div>
        <div class="col-4">
            <input type="couriel" id="couriel" name="Courriel" size="70" class="form-control" placeholder="Entrer votre courriel" required>
        </div>
        <div class="col-3">
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-2">
        </div>
        <div class="col-3 text-end pt-1">
            <label for="telephone" class="form-label">Téléphone : </label>
        </div>
        <div class="col-4">
            <input type='tel' id='phone' name='phone' pattern='[0-9]{3}-[0-9]{3}-[0-9]{4}' class="form-control" placeholder="999-999-9999" required>
        </div>
        <div class="col-3">
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-2">
        </div>
        <div class="col-3 text-end pt-1">
            <label for="Commentaire">Commentaire : </label>
        </div>
        <div class="col-5">
            <textarea id="commentaire" size="100" rows="8" cols="70" name="Commentaire" class="form-control" placeholder="Vos commentaires ..."></textarea>
        </div>
        <div class="col-2">
        </div>
    </div>

    <div class="row mb-3"">
        <div class=" col-5">
    </div>
    <div class="col-3">
        <input type="submit" class="btn btn-secondary text-light" value="Envoyer">
        <input type="reset" class="btn btn-secondary text-light" value="Annuler" class="col-3">
    </div>
    <div class="col-4">
    </div>
    </div>

</form>


<?php
include("include/foot.inc.php");
?>