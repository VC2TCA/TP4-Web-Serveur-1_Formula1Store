<?php
include("include/head.inc.php");
include("librairie/fonctionClient.lib.php");

if (isset($_GET['action'])) {
    if ($_GET['action'] == 'connexion') {
        if (verificationUser()) {
            if ($_POST['identifiant'] == 'admin') {
                header("Location:ajouterProduit.php");
            } else {
                header("Location:index.php");  // id ou password erronné
            }
        } else {
            echo "<div class='text-center'><span style='color:red;' class='text-center'>Le courriel ou le mot de passe est invalide!!!</span></div>";
        }
    }
}
?>

<body><br>
    <form action="connexionAdmin.php?action=connexion" method="post">
        <div class="row mb-3">
            <div class="col-2">
            </div>
            <div class="col-3 text-end">
                <label for="idAdmin">Identifiant : </label>
            </div>
            <div class="col-4">
                <input type="text" id="identifiant" name="identifiant" size="20" class="form-control" placeholder="Identifiant" required>
            </div>
            <div class="col-3">
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-2">
            </div>
            <div class="col-3 text-end">
                <label for="password">Mot de passe : </label>
            </div>
            <div class="col-4">
                <input type="password" id="password" name="password" size="15" class="form-control" placeholder="Mot de passe" required>
            </div>
            <div class="col-3">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-5">
            </div>
            <div class="col-2">
                <input type="submit" value="Connexion">
            </div>
            <div class="col-5">
            </div>
        </div>

    </form>
</body>
<?php
include("include/foot.inc.php");
?>