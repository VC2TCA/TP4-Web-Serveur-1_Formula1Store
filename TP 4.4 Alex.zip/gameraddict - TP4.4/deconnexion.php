<?php
    session_start();
    if (isset($_SESSION['idUsager']))
    {
        session_unset();
        setcookie("PHPSESSID", "", time()-3600, "/", "", 1);   
    }
    header("Location:index.php");
?>
