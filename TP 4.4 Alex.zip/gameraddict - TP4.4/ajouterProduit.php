<?php
session_start();
if (isset($_SESSION['idUsager'])) {
	if ($_SESSION['idUsager'] != 'admin') {
		header("Location:index.php");
	}
}

include("include/headadmin.inc.php");
include("librairie/fonctionAdmin.lib.php");

$valide = true;
if (isset($_GET['action'])) {
	if ($_GET['action'] == 'ajouter') {
		if (ajouterProduit()) {
			echo msgErr(5);   // Ajout produit dans table produit OK
		} else {
			echo msgErr(4);   // Ajout produit dans table produit en erreur !
		}
	}
}

?>
<br>
<form action="ajouterProduit.php?action=ajouter" enctype="multipart/form-data" method="post">

	<div class="row mb-3">
		<div class="col-2">
		</div>
		<div class="col-3 text-end pt-1">
			<label for="nomProduit">Votre nom : </label>
		</div>
		<div class="col-4">
			<input type="text" id="nomProduit" name="nomProduit" size="25" class="form-control" placeholder="Nom du produit" required>
		</div>
		<div class="col-3">
		</div>
	</div>

	<div class="row mb-3">
		<div class="col-2">
		</div>
		<div class="col-3 text-end pt-1">
			<label for="prix">Prix : </label>
		</div>
		<div class="col-4">
			<input type="text" id="prix" name="prix" size="10" class="form-control" placeholder="Prix $" required>
		</div>
		<div class="col-3">
		</div>
	</div>

	<div class="row mb-3">
		<div class="col-2">
		</div>
		<div class="col-3 text-end pt-1">
			<label for="fournisseur">Fournisseur : </label>
		</div>
		<div class="col-4">
			<select name="fournisseur" id="fournisseur" class="form-select">
				<option value="Sony">Sony</option>
				<option value="Microsoft">Microsoft</option>
				<option value="Steam">Steam</option>
				<option value="Nitendo">Nitendo</option>
				<option value="GooglePlay">GooglePlay</option>
				<option value="Activision">Activision</option>
			</select>
		</div>
		<div class="col-3">
		</div>
	</div>

	<div class="row mb-3">
		<div class="col-2">
		</div>
		<div class="col-3 text-end pt-1">
			<label for="quantite">Quantité pour l'inventaire : </label>
		</div>
		<div class="col-4">
			<input type='number' style='width:5rem' class='form-control' id='quantite' name='quantite' min='0' max='100'>
		</div>
		<div class="col-3">
		</div>
	</div>

	<div class="row mb-3">
		<div class="col-2">
		</div>
		<div class="col-3 text-end pt-1">
			<label for="console">Console de jeu : </label>
		</div>
		<div class="col-4">
			<select name="console" id="console" class="form-select">
				<option value="XBOX One">XBOX One</option>
				<option value="XBOX 360">XBOX 360</option>
				<option value="XBOX 720">XBOX 720</option>
				<option value="Play Station 4">Play Station 4</option>
				<option value="Play Station 5">Play Station 5</option>
				<option value="Play Station 8">Play Station 8</option>
				<option value="Nitendo Wii">Nitendo Wii</option>
				<option value="Nitendo Switch">Nitendo Switch</option>
				<option value="Steam Plus">Steam Plus</option>
				<option value="Sega">Sega</option>
			</select>
		</div>
		<div class="col-3">
		</div>
	</div>

	<div class="row mb-3">
		<div class="col-2">
		</div>
		<div class="col-3 text-end pt-1">
			<label for="description">Description : </label>
		</div>
		<div class="col-4">
			<textarea name="description" class="form-control" aria-label="Description" required></textarea>
		</div>
		<div class="col-3">
		</div>
	</div>

	<div class="row mb-3">
		<div class="col-2">
		</div>
		<div class="col-3 text-end pt-1">
			<label for="age">Age légal : </label>
		</div>
		<div class="col-4">
			<input type='number' style='width:5rem' class='form-control' id='age' name='age' min='9' max='21'>
		</div>
		<div class="col-3">
		</div>
	</div>

	<div class="row mb-3">
		<div class=" col-2">
		</div>
		<div class="col-3 text-end">
			<label for="avatar" class="form-label">Image du produit : </label>
		</div>
		<div class="col-4">
			<input type="hidden" name="MAX_FILE_SIZE" value="256000">
			<input class="form-control" type="file" size=60 name="image" id="fichier" required>
		</div>
		<div class="col-3">
		</div>
	</div>

	<div class="row mb-3"">
		<div class=" col-5">
	</div>
	<div class="col-3">
		<input type="submit" class="btn btn-secondary text-light" value="Créer">
		<input type="reset" class="btn btn-secondary text-light" value="Annuler">
	</div>
	<div class="col-4">
	</div>
	</div>

</form>
<?php
include("include/footadmin.inc.php");
?>